# Смета и кандидаты на закупку

Дата: 07.10.2026. Цены выдачи Ozon, часть с Ozon Картой; доставка и фактическая комплектация не проверены. WB API вернул 403; ссылки WB — поиск, наличие не подтверждено. Карточка — кандидат, совместимость проверять по последней колонке CSV. Непроверенные цены явно отмечены.

| Позиция | Кол-во MVP | ₽/ед. или комплект | ₽ MVP | Источник |
|---|---:|---:|---:|---|
| ESP32-CAM AI Thinker + OV2640 | 1 | 1034 | 1034 | [Ozon — выдача](https://www.ozon.ru/product/modul-esp32-cam-s-kameroy-1727032723/) |
| ESP32 DevKit 30 pin | 2 | 526 | 1052 | [Ozon — выдача](https://www.ozon.ru/product/esp32-devkit-otladochnaya-plata-esp32-ch340-type-c-sovmestima-s-arduino-ide-2056333551/) |
| RFM95W 868 МГц SPI | 2 | 819 | 1638 | [Ozon — выдача](https://www.ozon.ru/product/modul-besprovodnogo-transivera-rfm95w-868mhz-lora-modul-na-sx1276-2797194641/) |
| Антенна 868 SMA 1.5 dBi | 2 | 513 | 1026 | [Ozon — выдача](https://www.ozon.ru/product/antenna-antennahome-h50-rubber-sma-j-868-915-mgts-900-1800-mgts-ah1g-102-1-5-dbi-1818219492/) |
| Пигтейл SMA bulkhead 50 Ом под пайку | 2 | 250 | 500 | [Ozon — оценка](https://www.ozon.ru/search/?text=%D0%9F%D0%B8%D0%B3%D1%82%D0%B5%D0%B9%D0%BB%20SMA%20bulkhead%2050%20%D0%9E%D0%BC%20%D0%BF%D0%BE%D0%B4%20%D0%BF%D0%B0%D0%B9%D0%BA%D1%83) |
| AM312 PIR | 1 | 165 | 165 | [Ozon — выдача](https://www.ozon.ru/product/arduino-mini-pir-datchik-dvizheniya-am312-ir-sensor-3270057786/) |
| DS3231 RTC | 1 | 258 | 258 | [Ozon — выдача](https://www.ozon.ru/product/ds3231-rtc-modul-chasov-realnogo-vremeni-i2c-1401711129/) |
| CR2032 для RTC | 1 | 100 | 100 | [Ozon — оценка](https://www.ozon.ru/search/?text=CR2032%20%D0%B4%D0%BB%D1%8F%20RTC) |
| Камера/объектив NoIR совместимые с ESP32-CAM | 1 | 700 | 700 | [Ozon — оценка](https://www.ozon.ru/search/?text=%D0%9A%D0%B0%D0%BC%D0%B5%D1%80%D0%B0/%D0%BE%D0%B1%D1%8A%D0%B5%D0%BA%D1%82%D0%B8%D0%B2%20NoIR%20%D1%81%D0%BE%D0%B2%D0%BC%D0%B5%D1%81%D1%82%D0%B8%D0%BC%D1%8B%D0%B5%20%D1%81%20ESP32-CAM) |
| ИК LED 850 нм 1 Вт | 3 | 256 | 768 | [Ozon — выдача](https://www.ozon.ru/product/svetodiod-infrakrasnyy-ik-1vt-850nm-dlya-kamer-videonablyudeniya-3330994215/) |
| Резистор 18 Ом 2 Вт, комплект 3 шт | 1 | 150 | 150 | [Ozon — оценка](https://www.ozon.ru/search/?text=%D0%A0%D0%B5%D0%B7%D0%B8%D1%81%D1%82%D0%BE%D1%80%2018%20%D0%9E%D0%BC%202%D0%92%D1%82%2C%20%D0%BA%D0%BE%D0%BC%D0%BF%D0%BB%D0%B5%D0%BA%D1%82%203%D1%88%D1%82) |
| Радиатор для LED, комплект 3 шт | 1 | 200 | 200 | [Ozon — оценка](https://www.ozon.ru/search/?text=%D0%A0%D0%B0%D0%B4%D0%B8%D0%B0%D1%82%D0%BE%D1%80%20%D0%B4%D0%BB%D1%8F%20LED%2C%20%D0%BA%D0%BE%D0%BC%D0%BF%D0%BB%D0%B5%D0%BA%D1%82%203%D1%88%D1%82) |
| AO3400 N-MOSFET комплект | 1 | 113 | 113 | [Ozon — выдача](https://www.ozon.ru/product/ao3400-tranzistor-polevoy-mosfet-n-kanalnyy-10sht-sot-23-5-8a-30v-4651074746/) |
| AO3401 P-MOSFET комплект | 1 | 128 | 128 | [Ozon — выдача](https://www.ozon.ru/product/ao3401-10sht-a19t-polevoy-tranzistor-p-kanalnyy-30v-4a-0-04-om-korpus-sot-23-markirovka-a19t-2716415055/) |
| 2N3904 | 1 | 80 | 80 | [Ozon — выдача](https://www.ozon.ru/product/tranzistor-2n3904-n-p-n-korpus-to-92-3334701557/) |
| Переходники SOT23, комплект | 1 | 120 | 120 | [Ozon — оценка](https://www.ozon.ru/search/?text=%D0%9F%D0%B5%D1%80%D0%B5%D1%85%D0%BE%D0%B4%D0%BD%D0%B8%D0%BA%D0%B8%20SOT23%2C%20%D0%BA%D0%BE%D0%BC%D0%BF%D0%BB%D0%B5%D0%BA%D1%82) |
| Резисторы набор | 1 | 247 | 247 | [Ozon — выдача](https://www.ozon.ru/product/komplekt-rezistorov-0-25vt-1-30-nominalov-20-sht-vsego-600-sht-4839946078/) |
| 18650 с защитой 3400 мАч | 1 | 358 | 358 | [Ozon — выдача](https://www.ozon.ru/product/akkumulyator-18650-s-zashchitoy-ncr18650b-3400-mach-3-7-v-s-vypuklym-plyusom-dlya-panasonic-1-sht-630286903/) |
| Держатель 1x18650 | 1 | 196 | 196 | [Ozon — выдача](https://www.ozon.ru/product/batareynyy-otsek-dlya-li-ion-1x18650-3010498976/) |
| Повышающий DC/DC 5 В | 1 | 226 | 226 | [Ozon — выдача](https://www.ozon.ru/product/povyshayushchiy-preobrazovatel-napryazheniya-uvh-2-24v-uvyh-5-35v-max-2a-dc-dc-reguliruemyy-mt3608-1148481024/) |
| TP4056 с защитой | 1 | 71 | 71 | [Ozon — выдача](https://www.ozon.ru/product/plata-zaryadki-tp4056-usb-type-c-s-zashchitoy-modul-zaryadnogo-ustroystva-li-ion-621665762/) |
| Предохранитель 2 А 5x20, комплект | 1 | 213 | 213 | [Ozon — выдача](https://www.ozon.ru/product/10sht-5h20mm-predohranitel-steklo-2a-250v-vstavka-plavkaya-3255734479/) |
| Держатель предохранителя | 1 | 100 | 100 | [Ozon — оценка](https://www.ozon.ru/search/?text=%D0%94%D0%B5%D1%80%D0%B6%D0%B0%D1%82%D0%B5%D0%BB%D1%8C%20%D0%BF%D1%80%D0%B5%D0%B4%D0%BE%D1%85%D1%80%D0%B0%D0%BD%D0%B8%D1%82%D0%B5%D0%BB%D1%8F) |
| Выключатель питания | 1 | 100 | 100 | [Ozon — оценка](https://www.ozon.ru/search/?text=%D0%92%D1%8B%D0%BA%D0%BB%D1%8E%D1%87%D0%B0%D1%82%D0%B5%D0%BB%D1%8C%20%D0%BF%D0%B8%D1%82%D0%B0%D0%BD%D0%B8%D1%8F) |
| Коробка 150x110x70 | 1 | 215 | 215 | [Ozon — выдача](https://www.ozon.ru/product/korobka-raspredelitelnaya-dlya-provodov-150h110h70mm-11-vvodov-ip67-chernaya-1sht-3260072910/) |
| Гермоввод PG7, комплект | 1 | 95 | 95 | [Ozon — выдача](https://www.ozon.ru/product/kabelnyy-vvod-pg7-germovvod-salnik-dlya-kabelya-ip68-3-6-5-mm-5-sht-1848678618/) |
| Конденсаторы 470 мкФ 16 В комплект | 1 | 93 | 93 | [Ozon — выдача](https://www.ozon.ru/product/470mkf-16v-kondensator-elektroliticheskiy-aishi-seriya-rs-470uf-16v-40-105-8x12mm-5-sht-3298289075/) |
| Макетная плата пайка | 2 | 161 | 322 | [Ozon — выдача](https://www.ozon.ru/product/pechatnaya-maketnaya-plata-5-x-7-sm-dvuhstoronnyaya-dlya-payki-pcb1-zelenyy-3747803704/) |
| USB TTL CH340 3.3V | 1 | 123 | 123 | [Ozon — выдача](https://www.ozon.ru/product/preobrazovatel-usb-serial-usb-ttl-uart-mikrokontroller-adapter-ch340g-3-3v-5v-630272153/) |
| БП базы 5 В 2 А + USB кабель | 1 | 400 | 400 | [Ozon — оценка](https://www.ozon.ru/search/?text=%D0%91%D0%9F%20%D0%B1%D0%B0%D0%B7%D1%8B%205%D0%92%202%D0%90%20%2B%20USB%20%D0%BA%D0%B0%D0%B1%D0%B5%D0%BB%D1%8C) |
| Провода, разъёмы, термоусадка, 100 нФ, винты, силикагель | 1 | 650 | 650 | [Ozon — оценка](https://www.ozon.ru/search/?text=%D0%9F%D1%80%D0%BE%D0%B2%D0%BE%D0%B4%D0%B0%2C%20%D1%80%D0%B0%D0%B7%D1%8A%D1%91%D0%BC%D1%8B%2C%20%D1%82%D0%B5%D1%80%D0%BC%D0%BE%D1%83%D1%81%D0%B0%D0%B4%D0%BA%D0%B0%2C%20100%D0%BD%D0%A4%2C%20%D0%B2%D0%B8%D0%BD%D1%82%D1%8B%2C%20%D1%81%D0%B8%D0%BB%D0%B8%D0%BA%D0%B0%D0%B3%D0%B5%D0%BB%D1%8C) |
| Стекло окна камеры, прокладки и нейтральный герметик | 1 | 350 | 350 | [Ozon — оценка](https://www.ozon.ru/search/?text=%D0%A1%D1%82%D0%B5%D0%BA%D0%BB%D0%BE%20%D0%BE%D0%BA%D0%BD%D0%B0%20%D0%BA%D0%B0%D0%BC%D0%B5%D1%80%D1%8B%2C%20%D0%BF%D1%80%D0%BE%D0%BA%D0%BB%D0%B0%D0%B4%D0%BA%D0%B8%20%D0%B8%20%D0%BD%D0%B5%D0%B9%D1%82%D1%80%D0%B0%D0%BB%D1%8C%D0%BD%D1%8B%D0%B9%20%D0%B3%D0%B5%D1%80%D0%BC%D0%B5%D1%82%D0%B8%D0%BA) |
| 3D-печать монтажной пластины и оптической перегородки | 1 | 800 | 800 | [Ozon — оценка](https://www.ozon.ru/search/?text=3D-%D0%BF%D0%B5%D1%87%D0%B0%D1%82%D1%8C%20%D0%BC%D0%BE%D0%BD%D1%82%D0%B0%D0%B6%D0%BD%D0%BE%D0%B9%20%D0%BF%D0%BB%D0%B0%D1%81%D1%82%D0%B8%D0%BD%D1%8B%20%D0%B8%20%D0%BE%D0%BF%D1%82%D0%B8%D1%87%D0%B5%D1%81%D0%BA%D0%BE%D0%B9%20%D0%BF%D0%B5%D1%80%D0%B5%D0%B3%D0%BE%D1%80%D0%BE%D0%B4%D0%BA%D0%B8) |

MVP (узел + база, включая печать): **12,591 ₽**. С резервом 25%: **15,739 ₽**. Четыре узла + одна база: **40,044 ₽**, с резервом 25% **50,055 ₽**. Это плановая смета с кандидатами, а не готовая подтверждённая корзина.

Не включены: компьютер базы, инструменты, труд, доставка, мачта/антенный крепёж, поездки, повторная закупка неподошедшей камеры и ретранслятор. Если печать не нужна, вычесть 800 ₽/пост.

Солнечный комплект отдельно: панель 6 В 4.5 Вт (Ozon кандидат 3496213375, выдача 813 ₽), CN3065 (1768211332, 317 ₽), защита батареи/температурная блокировка заряда/power-path/корпус/крепёж и провод — бюджет ещё 1 500–3 000 ₽. Итого ориентир 2 630–4 130 ₽/пост. Панель с Voc >6 В нельзя подключать к обычной плате CN3065 без проверки её пределов. TP4056 не является солнечным контроллером.
