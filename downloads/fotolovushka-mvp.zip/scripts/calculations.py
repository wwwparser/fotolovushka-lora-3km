"""Deterministic LoRa time-on-air and radio-budget calculations (explicit assumptions)."""
import json
import math
from pathlib import Path

def toa(n,sf,bw=125000,cr=1,preamble=8):
    de=int(sf>=11 and bw==125000)
    symbol=2**sf/bw
    payload=8+max(math.ceil((8*n-4*sf+28+16)/(4*(sf-2*de)))*(cr+4),0)
    return (preamble+4.25+payload)*symbol

def main():
    rows=[]
    for size in (5120,10240,15360):
        lengths=[min(200,size-i) for i in range(0,size,200)]
        for sf in (7,9,12):
            tx=sum(toa(26+n,sf) for n in lengths)
            ack=len(lengths)*toa(26,sf)
            duty=.01
            rows.append({'jpeg_bytes':size,'sf':sf,'packets':len(lengths),
                         'node_air_s':round(tx,3),'gateway_ack_air_s':round(ack,3),
                         'continuous_ideal_s':round(tx+ack,3),
                         'node_air_budget_1pct_s':round(tx/duty,1),
                         'max_images_per_day_1pct':round(86400*duty/tx,2)})
    Path('docs').mkdir(exist_ok=True)
    Path('docs/airtime.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
    md='| JPEG | SF | Пакетов | Эфир узла, с | ACK базы, с | Бюджет времени при 1%, мин | Максимум кадров/сутки узла при 1% |\n|---|---|---|---|---|---|---|\n'
    for r in rows:
        md+=f"| {r['jpeg_bytes']//1024} КиБ | {r['sf']} | {r['packets']} | {r['node_air_s']} | {r['gateway_ack_air_s']} | {r['node_air_budget_1pct_s']/60:.1f} | {r['max_images_per_day_1pct']} |\n"
    Path('docs/airtime.md').write_text(md,encoding='utf-8')
    print(md)
    fspl=32.44+20*math.log10(868.95)+20*math.log10(3)
    fresnel=math.sqrt((299792458/868950000)*1500*1500/3000)
    print(f'FSPL 3 km: {fspl:.1f} dB; Fresnel midpoint radius: {fresnel:.1f} m')

if __name__=='__main__':main()
