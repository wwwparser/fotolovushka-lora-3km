"""Original parametric teaching enclosure. mm. CadQuery installed locally.
Run: python cad/enclosure_v02.py. Output: cad/export + assets/case-mesh.json.
Component shapes are clearance envelopes, not manufacturer CAD models.
"""
from pathlib import Path
import json,math
import cadquery as cq
import numpy as np
import trimesh

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent if HERE.name=='cad' else HERE
OUT=HERE/'export';OUT.mkdir(parents=True,exist_ok=True)
(ROOT/'assets').mkdir(exist_ok=True)
W,H,D,WALL,LID=130.0,190.0,70.0,4.0,4.0
CAM=(65.0,153.0);PIR=(65.0,108.0);IR=(65.0,55.0)
BOLTS=[(9,9),(121,9),(9,181),(121,181)]
TRAY_BOLTS=[(22,22),(108,22),(22,168),(108,168)]

def block(x,y,z,w,h,d):
    return cq.Workplane('XY').box(w,h,d,centered=(False,False,False)).translate((x,y,z))
def rounded(x,y,z,w,h,d,r):
    return block(x,y,z,w,h,d).edges('|Z').fillet(r)
def cyl(x,y,z,r,h):
    return cq.Workplane('XY').circle(r).extrude(h).translate((x,y,z))
def ring_rect(x,y,z,w,h,d,b,r):
    outer=rounded(x,y,z,w,h,d,r)
    inner=rounded(x+b,y+b,z-1,w-2*b,h-2*b,d+2,max(.1,r-b))
    return outer.cut(inner)

def models():
    body=rounded(0,0,0,W,H,D,5)
    body=body.cut(rounded(WALL,WALL,WALL,W-2*WALL,H-2*WALL,D,1))
    for x,y in BOLTS:
        body=body.union(cyl(x,y,WALL,6,D-WALL))
        body=body.cut(cyl(x,y,D-6,2.3,7)) # M3 heat-insert pilot, verify insert supplier diameter
    for x,y in TRAY_BOLTS:
        body=body.union(cyl(x,y,3,5,9))
        body=body.cut(cyl(x,y,7,1.3,6)) # M3 pilot, tap/resize after trial print
    # SMA through left wall, PG7 through lower wall. Both require purchased seals.
    antenna=cq.Workplane('YZ').circle(3.25).extrude(8).translate((-2,158,48))
    gland=cq.Workplane('XZ').circle(6.6).extrude(8,both=True).translate((65,0,26))
    body=body.cut(antenna).cut(gland)
    # Rear strap bridge: two separately printable parts, bolt to blind holes.
    for x in [25,105]:
        for y in [66,124]:
            body=body.union(cyl(x,y,3,5,8)).cut(cyl(x,y,-1,2.3,6))
    lid=rounded(0,0,0,W,H,LID,5)
    for x,y in BOLTS:lid=lid.cut(cyl(x,y,-1,1.7,LID+2))
    lid=lid.cut(cyl(*CAM,-1,10,LID+2)).cut(cyl(*PIR,-1,6.5,LID+2))
    lid=lid.cut(rounded(IR[0]-38,IR[1]-12,-1,76,24,LID+2,3))
    # Seal groove is on back (z=0), exactly over the 4 mm body wall.
    groove=ring_rect(.8,.8,-.1,W-1.6,H-1.6,1.3,2.4,4.2)
    lid=lid.cut(groove)
    for x in [20,110]:lid=lid.cut(cyl(x,55,-1,1.3,6))
    # Universal attachment holes behind camera/PIR; heads sealed after assembly.
    for x,y in [(42,126),(88,126),(42,156),(88,156),(52,108),(78,108)]:
        lid=lid.cut(cyl(x,y,-1,1.3,6))
    tray=rounded(8,8,0,114,174,3,3)
    for x,y in BOLTS:tray=tray.cut(cyl(x,y,-1,6.8,5))
    for x,y in TRAY_BOLTS:tray=tray.cut(cyl(x,y,-1,1.7,5))
    for x in [28,62,96]:
        for y in [39,78,117,148]:tray=tray.cut(rounded(x-8,y-2,-1,16,4,5,1))
    # Light barrier: separate tube mounted against rear of camera window.
    baffle=cyl(0,0,0,17,2).union(cyl(0,0,0,12,17)).cut(cyl(0,0,-1,10,20))
    window_frame=ring_rect(0,0,0,106,36,3,6,3)
    # Frame clear opening is wider than front opening; no glass included in STL.
    for x in [8,98]:window_frame=window_frame.cut(cyl(x,18,-1,1.3,5))
    # Universal slotted camera support, no claim of matching exact PCB holes.
    camera_carrier=rounded(0,0,0,60,52,3,3)
    camera_carrier=camera_carrier.cut(cyl(30,37,-1,10,5))
    for x in [7,53]:
        for y in [10,40]:camera_carrier=camera_carrier.cut(rounded(x-2,y-6,-1,4,12,5,1))
    # Short visor fastens/glues above lens, separately printed on side.
    hood=block(0,0,0,70,22,3).union(block(0,0,0,70,3,16))
    strap=block(0,0,0,12,70,3).union(block(0,0,0,12,12,8)).union(block(0,58,0,12,12,8))
    for y in [6,64]:strap=strap.cut(cyl(6,y,-1,1.7,10))
    gasket=ring_rect(.8,.8,0,W-1.6,H-1.6,1.8,2.4,4.2)
    coupon=block(0,0,0,56,28,4)
    for i,d in enumerate([3.4,4.3,4.6,6.5,13.2]):coupon=coupon.cut(cyl(7+i*10,14,-1,d/2,6))
    return {'body':body,'lid':lid,'tray':tray,'camera_baffle':baffle,'ir_retainer':window_frame,
            'camera_carrier':camera_carrier,'rain_hood':hood,'strap_bridge':strap,'gasket_trial':gasket,'fit_coupon':coupon}

def mesh_shape(shape):
    vertices,faces=shape.val().tessellate(.35,.15)
    return trimesh.Trimesh(vertices=np.array([[v.x,v.y,v.z] for v in vertices]),faces=np.array(faces),process=True)

def main():
    parts=models();report={}
    for name,part in parts.items():
        assert part.val().isValid(),name
        assert len(part.solids().vals())==1,(name,'disconnected solids')
        cq.exporters.export(part,str(OUT/(name+'.step')))
        cq.exporters.export(part,str(OUT/(name+'.stl')),tolerance=.12,angularTolerance=.1)
        mesh=trimesh.load(OUT/(name+'.stl'),force='mesh')
        assert mesh.is_watertight,(name,'open mesh')
        assert mesh.volume>0,name
        bb=part.val().BoundingBox()
        report[name]={'solid_valid':True,'watertight':True,'triangles':len(mesh.faces),
                     'dimensions_mm':[round(bb.xlen,2),round(bb.ylen,2),round(bb.zlen,2)],
                     'volume_cm3':round(part.val().Volume()/1000,2)}
    assembly=cq.Assembly(name='ForestCase_v02')
    assembly.add(parts['body'],name='body',color=cq.Color(.38,.41,.38))
    assembly.add(parts['lid'],name='front_lid',loc=cq.Location(cq.Vector(0,0,D)),color=cq.Color(.48,.51,.48))
    assembly.add(parts['tray'],name='mounting_tray',loc=cq.Location(cq.Vector(0,0,12)),color=cq.Color(.2,.28,.2))
    assembly.add(parts['camera_baffle'],name='light_barrier',loc=cq.Location(cq.Vector(CAM[0],CAM[1],D-17)),color=cq.Color(.08,.08,.08))
    assembly.add(parts['camera_carrier'],name='camera_carrier',loc=cq.Location(cq.Vector(35,116,50)),color=cq.Color(.15,.22,.15))
    assembly.add(parts['ir_retainer'],name='ir_retainer',loc=cq.Location(cq.Vector(12,37,65)),color=cq.Color(.12,.12,.12))
    assembly.save(str(OUT/'assembly.step'))
    # Real geometry for an offline browser viewer; no external CDN required.
    viewer={}
    for name in ['body','lid','tray','camera_baffle','ir_retainer','camera_carrier']:
        mesh=mesh_shape(parts[name]);viewer[name]={'v':np.round(mesh.vertices,3).tolist(),'f':mesh.faces.tolist()}
    (ROOT/'assets/case-mesh.json').write_text(json.dumps(viewer,separators=(',',':')),encoding='utf-8')
    (OUT/'geometry-check.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    params={'units':'mm','case':[W,H,D+LID],'body_depth':D,'wall':WALL,'lid':LID,
            'camera_xy':CAM,'pir_xy':PIR,'ir_xy':IR,'inner_clear_box':[W-2*WALL,H-2*WALL,D-WALL],
            'insert_pilot_mm':4.6,'sma_hole_mm':6.5,'pg7_hole_mm':13.2,
            'status':'geometry checked; physical fit, print, seal and purchased-board dimensions unverified'}
    (OUT/'parameters.json').write_text(json.dumps(params,indent=2),encoding='utf-8')
    # Mandatory mounting clearance checks; intentionally excluded soft seal / optical glass.
    positioned={'body':parts['body'],'lid':parts['lid'].translate((0,0,D)),
      'tray':parts['tray'].translate((0,0,12)),
      'baffle':parts['camera_baffle'].translate((CAM[0],CAM[1],D-17)),
      'carrier':parts['camera_carrier'].translate((35,116,50)),
      'retainer':parts['ir_retainer'].translate((12,37,65))}
    collisions=[]
    import itertools
    for (a,x),(b,y) in itertools.combinations(positioned.items(),2):
        overlap=x.val().intersect(y.val()).Volume()
        if overlap>0.01:collisions.append({'parts':[a,b],'overlap_mm3':round(overlap,3)})
    (OUT/'assembly-check.json').write_text(json.dumps({'hard_part_collisions':collisions,'status':'purchased hardware not included'},indent=2),encoding='utf-8')
    assert not collisions,collisions
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
