Generic prototype adapters, mm. NOT measured Filin mounting pattern.
Measure donor and boards; paper template and fit coupon before printing.
rear_plate 70x95x3; camera_carrier 54x58x3; optical_baffle height16.
Watertight mesh does not establish weatherproof enclosure.
