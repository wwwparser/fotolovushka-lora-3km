"""Generic adapters for a measured used Filin shell; NOT verified factory geometry.
Units mm. Edit dimensions only after measuring the actual donor.
Dependencies: cadquery, trimesh, numpy. Exports beside this script.
"""
from pathlib import Path
import json
import cadquery as cq
import trimesh
HERE=Path(__file__).resolve().parent
OUT=HERE/'filin-export';OUT.mkdir(exist_ok=True)
WIDTH,HEIGHT,THICK=70.,95.,3.
CAM_WIDTH,CAM_HEIGHT=54.,58.
BAFFLE_HEIGHT=16.
def slot(part,x,y,w,h):
    tool=cq.Workplane('XY').center(x,y).rect(w,h).extrude(THICK+2).translate((0,0,-1))
    return part.cut(tool)
def main():
    rear=cq.Workplane('XY').box(WIDTH,HEIGHT,THICK,centered=(False,False,False)).edges('|Z').fillet(2)
    for x in [8,WIDTH-8]:
        for y in [10,HEIGHT-10]:rear=slot(rear,x,y,4,14)
    for x in [22,48]:
        for y in [30,55,78]:rear=slot(rear,x,y,16,3)
    carrier=cq.Workplane('XY').box(CAM_WIDTH,CAM_HEIGHT,THICK,centered=(False,False,False)).edges('|Z').fillet(2)
    carrier=carrier.cut(cq.Workplane('XY').center(CAM_WIDTH/2,40).circle(10).extrude(THICK+2).translate((0,0,-1)))
    for x in [7,CAM_WIDTH-7]:
        for y in [11,44]:carrier=slot(carrier,x,y,4,14)
    baffle=cq.Workplane('XY').circle(17).extrude(2).union(cq.Workplane('XY').circle(12).extrude(BAFFLE_HEIGHT))
    baffle=baffle.cut(cq.Workplane('XY').circle(10).extrude(BAFFLE_HEIGHT+2).translate((0,0,-1)))
    coupon=cq.Workplane('XY').box(50,20,3,centered=(False,False,False))
    for x,d in [(8,3.4),(20,4.6),(36,6.5)]:coupon=coupon.cut(cq.Workplane('XY').center(x,10).circle(d/2).extrude(5).translate((0,0,-1)))
    report={}
    for name,part in {'rear_plate':rear,'camera_carrier':carrier,'optical_baffle':baffle,'fit_coupon':coupon}.items():
        cq.exporters.export(part,str(OUT/(name+'.step')))
        cq.exporters.export(part,str(OUT/(name+'.stl')),tolerance=.07,angularTolerance=.15)
        mesh=trimesh.load_mesh(OUT/(name+'.stl'));shape=part.val()
        assert shape.isValid() and mesh.is_watertight and shape.Volume()>0
        report[name]={'solid_valid':True,'watertight_mesh':True,'dimensions_mm':mesh.extents.round(3).tolist(),'volume_cm3':round(shape.Volume()/1000,3)}
    (OUT/'geometry-check.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    (OUT/'README.txt').write_text('Generic prototype adapters, mm. NOT measured Filin mounting pattern.\nMeasure donor and boards; paper template and fit coupon before printing.\nrear_plate 70x95x3; camera_carrier 54x58x3; optical_baffle height16.\nWatertight mesh does not establish weatherproof enclosure.\n',encoding='utf-8')
    print(json.dumps(report,indent=2))
if __name__=='__main__':main()
