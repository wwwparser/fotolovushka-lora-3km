"""Wire format shared with firmware/common/protocol.h. No LoRaWAN."""
import math
import struct
import zlib
from dataclasses import dataclass

HEADER = struct.Struct('<2sBBHIHHIII')
CHUNK = 200
MAX_IMAGE = 32768
DATA, ACK = 1, 2

@dataclass(frozen=True)
class Packet:
    kind: int
    node: int
    image: int
    index: int
    total: int
    captured: int
    size: int
    crc: int
    payload: bytes = b''

    def validate(self):
        if self.kind not in (DATA, ACK) or not 1 <= self.node <= 4:
            raise ValueError('invalid type/node')
        if not 1 <= self.size <= MAX_IMAGE or self.total != math.ceil(self.size / CHUNK):
            raise ValueError('invalid image size/count')
        if not 0 <= self.index < self.total:
            raise ValueError('invalid fragment index')
        expected = min(CHUNK, self.size - self.index * CHUNK) if self.kind == DATA else 0
        if len(self.payload) != expected:
            raise ValueError('invalid payload length')

    def encode(self):
        self.validate()
        return HEADER.pack(b'FT', 1, self.kind, self.node, self.image, self.index,
                           self.total, self.captured, self.size, self.crc) + self.payload

    @classmethod
    def decode(cls, raw):
        if len(raw) < HEADER.size or len(raw) > HEADER.size + CHUNK:
            raise ValueError('invalid packet length')
        magic, version, *values = HEADER.unpack(raw[:HEADER.size])
        if magic != b'FT' or version != 1:
            raise ValueError('unknown protocol')
        p = cls(*values, raw[HEADER.size:])
        p.validate()
        return p

    def ack(self):
        return Packet(ACK, self.node, self.image, self.index, self.total,
                      self.captured, self.size, self.crc)

def fragment(jpeg, node, image, captured):
    crc = zlib.crc32(jpeg)
    total = math.ceil(len(jpeg) / CHUNK)
    for i in range(total):
        p = Packet(DATA, node, image, i, total, captured, len(jpeg), crc,
                   jpeg[i * CHUNK:(i + 1) * CHUNK])
        p.validate()
        yield p
