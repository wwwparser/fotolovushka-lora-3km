import argparse
import json
import logging
import random
import secrets
import threading
import time
from pathlib import Path
from .protocol import fragment,Packet,ACK
from .receiver import Receiver
from .services.mailer import send_image

def demo(args):
    source = Path(args.image)
    jpeg = source.read_bytes()
    if not (jpeg.startswith(b'\xff\xd8') and jpeg.endswith(b'\xff\xd9')):
        raise ValueError('Input must be a JPEG')
    image_id = secrets.randbits(32)
    packets = list(fragment(jpeg,1,image_id,int(time.time())))
    rng = random.Random(args.seed)
    receiver = Receiver(args.output)
    attempts = 0
    try:
        for p in packets:
            for _ in range(20):
                attempts += 1
                if rng.random() < args.loss:
                    continue
                ack, _ = receiver.accept(p.encode())
                if rng.random() < args.loss:
                    continue
                decoded = Packet.decode(ack)
                if decoded.kind == ACK and decoded == p.ack():
                    break
            else:
                raise RuntimeError('retry limit exceeded')
        target = Path(args.output)/f'post-1_{image_id:08x}.jpg'
        assert target.read_bytes() == jpeg, 'received bytes differ'
        summary = {'input':str(source),'output':str(target),'bytes':len(jpeg),'packets':len(packets),
                   'attempts':attempts,'loss_probability':args.loss,'identical':True,'smtp_sent':False}
        Path(args.output,'demo-report.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
        print(json.dumps(summary,ensure_ascii=False,indent=2))
    finally:
        receiver.close()

def mail_queue(receiver):
    for node,img,path in receiver.pending():
        try:
            send_image(path)
        except Exception as exc:
            logging.error('Email stays queued: %s',exc)
            break
        receiver.mark_sent(node,img)

def listen(args):
    from .services.serial_gateway import SerialGateway
    gateway,receiver = SerialGateway(args.port),Receiver(args.output)
    stop = threading.Event()
    worker = None
    if args.send_email:
        def send_worker():
            queue = Receiver(args.output)
            try:
                while not stop.is_set():
                    mail_queue(queue)
                    stop.wait(60)
            finally:
                queue.close()
        worker=threading.Thread(target=send_worker,daemon=True)
        worker.start()
    try:
        while True:
            try:
                raw = gateway.poll()
                if raw:
                    ack,path = receiver.accept(raw)
                    gateway.ack(ack)
                    if path:
                        logging.info('Saved %s',path)
            except ValueError as exc:
                logging.warning('Rejected packet: %s',exc)
    finally:
        stop.set()
        if worker:worker.join(timeout=35)
        gateway.close()
        receiver.close()

def main():
    logging.basicConfig(level=logging.INFO,format='%(levelname)s %(message)s')
    parser = argparse.ArgumentParser(description='LoRa photo MVP')
    sub = parser.add_subparsers(dest='cmd',required=True)
    d = sub.add_parser('demo')
    d.add_argument('--image',default='assets/sample.jpg')
    d.add_argument('--output',default='output/demo')
    d.add_argument('--loss',type=float,default=0.2)
    d.add_argument('--seed',type=int,default=7)
    d.set_defaults(func=demo)
    l = sub.add_parser('listen')
    l.add_argument('--port',required=True)
    l.add_argument('--output',default='data')
    l.add_argument('--send-email',action='store_true')
    l.set_defaults(func=listen)
    q = sub.add_parser('send-pending')
    q.add_argument('--output',default='data')
    def flush(a):
        r=Receiver(a.output)
        try: mail_queue(r)
        finally: r.close()
    q.set_defaults(func=flush)
    args=parser.parse_args()
    if args.cmd == 'demo' and not 0 <= args.loss < 1:
        parser.error('--loss must be >= 0 and < 1')
    args.func(args)

if __name__ == '__main__':
    main()
