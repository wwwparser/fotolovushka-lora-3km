"""Durable fragments, completion and email queue in SQLite."""
import json
import sqlite3
import time
import zlib
from datetime import datetime, timezone
from pathlib import Path
from .protocol import Packet, DATA

class Receiver:
    def __init__(self, root):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(self.root / 'state.sqlite')
        self.db.executescript('''
        PRAGMA journal_mode=WAL;
        CREATE TABLE IF NOT EXISTS images (
          node INTEGER, image INTEGER, total INTEGER, captured INTEGER, size INTEGER,
          crc INTEGER, first_seen INTEGER, completed TEXT, sent INTEGER DEFAULT 0,
          PRIMARY KEY(node,image));
        CREATE TABLE IF NOT EXISTS chunks (
          node INTEGER, image INTEGER, idx INTEGER, payload BLOB,
          PRIMARY KEY(node,image,idx));
        ''')

    def close(self):
        self.db.close()

    def accept(self, raw):
        p = Packet.decode(raw)
        if p.kind != DATA:
            raise ValueError('receiver accepts DATA only')
        now = int(time.time())
        with self.db:
            # Bound stale incomplete state; keep completed IDs for duplicate suppression.
            self.db.execute('DELETE FROM chunks WHERE (node,image) IN '
                            '(SELECT node,image FROM images WHERE completed IS NULL AND first_seen < ?)', (now-86400,))
            self.db.execute('DELETE FROM images WHERE completed IS NULL AND first_seen < ?', (now-86400,))
            row = self.db.execute('SELECT total,captured,size,crc,first_seen,completed FROM images WHERE node=? AND image=?',
                                  (p.node, p.image)).fetchone()
            if row is None:
                count = self.db.execute('SELECT COUNT(*) FROM images WHERE completed IS NULL').fetchone()[0]
                if count >= 16:
                    raise ValueError('too many incomplete images')
                self.db.execute('INSERT INTO images(node,image,total,captured,size,crc,first_seen) VALUES(?,?,?,?,?,?,?)',
                                (p.node, p.image, p.total, p.captured, p.size, p.crc, now))
                row = (p.total, p.captured, p.size, p.crc, now, None)
            if row[:4] != (p.total, p.captured, p.size, p.crc):
                raise ValueError('conflicting image metadata')
            if row[5]:
                return p.ack().encode(), Path(row[5])
            old = self.db.execute('SELECT payload FROM chunks WHERE node=? AND image=? AND idx=?',
                                  (p.node,p.image,p.index)).fetchone()
            if old and old[0] != p.payload:
                raise ValueError('conflicting duplicate')
            self.db.execute('INSERT OR IGNORE INTO chunks VALUES(?,?,?,?)',
                            (p.node,p.image,p.index,p.payload))
            chunks = self.db.execute('SELECT payload FROM chunks WHERE node=? AND image=? ORDER BY idx',
                                     (p.node,p.image)).fetchall()
            completed = None
            if len(chunks) == p.total:
                jpeg = b''.join(x[0] for x in chunks)
                if zlib.crc32(jpeg) != p.crc or not (jpeg.startswith(b'\xff\xd8') and jpeg.endswith(b'\xff\xd9')):
                    raise ValueError('CRC/JPEG check failed; final fragment not acknowledged')
                completed = self.root / f'post-{p.node}_{p.image:08x}.jpg'
                temp = completed.with_suffix('.tmp')
                temp.write_bytes(jpeg)
                temp.replace(completed)
                ts = p.captured or row[4]
                metadata = {'node':p.node, 'image':p.image, 'captured_utc':datetime.fromtimestamp(ts, timezone.utc).isoformat(),
                            'time_source':'node_rtc' if p.captured else 'base_first_fragment_estimate',
                            'received_utc':datetime.fromtimestamp(now, timezone.utc).isoformat(), 'bytes':p.size, 'crc32':p.crc}
                completed.with_suffix('.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2),encoding='utf-8')
                self.db.execute('UPDATE images SET completed=? WHERE node=? AND image=?', (str(completed),p.node,p.image))
                self.db.execute('DELETE FROM chunks WHERE node=? AND image=?',(p.node,p.image))
        # ACK only after SQLite commit and completed-file writes.
        return p.ack().encode(), completed

    def pending(self):
        return self.db.execute('SELECT node,image,completed FROM images WHERE completed IS NOT NULL AND sent=0').fetchall()

    def mark_sent(self,node,image):
        with self.db:
            self.db.execute('UPDATE images SET sent=1 WHERE node=? AND image=?',(node,image))
