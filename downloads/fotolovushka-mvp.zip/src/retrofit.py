"""Offline import of finished camera JPEGs. Never mount/share a live camera SD."""
import argparse,hashlib,io,json,sqlite3,time
from pathlib import Path
from PIL import Image,ImageOps

def preview(raw,limit=5120):
    with Image.open(io.BytesIO(raw)) as im:
        im.load()
        if im.format!='JPEG':raise ValueError('Only complete JPEG inputs are accepted')
        image=ImageOps.exif_transpose(im).convert('RGB');image.thumbnail((160,120))
        for quality in [65,50,35,25,15,8]:
            buf=io.BytesIO();image.save(buf,format='JPEG',quality=quality,optimize=True)
            if len(buf.getvalue())<=limit:return buf.getvalue()
        raise ValueError('Preview exceeds byte budget')

def ingest(source,output):
    source=Path(source).resolve();output=Path(output).resolve()
    if source==output or source in output.parents:raise ValueError('Output must be outside input directory')
    if not source.is_dir():raise ValueError('Input directory does not exist')
    folder=output/'previews';folder.mkdir(parents=True,exist_ok=True)
    db=sqlite3.connect(output/'queue.sqlite')
    db.execute('CREATE TABLE IF NOT EXISTS jobs(sha256 TEXT PRIMARY KEY, source TEXT, preview TEXT, imported_utc INTEGER, status TEXT)')
    report={'imported':0,'duplicates':0,'rejected':[]}
    try:
        for path in sorted(source.rglob('*')):
            if not path.is_file() or path.suffix.lower() not in ['.jpg','.jpeg']:continue
            try:
                raw=path.read_bytes()
                if not raw.startswith(b'\xff\xd8') or not raw.endswith(b'\xff\xd9'):raise ValueError('Incomplete JPEG')
                digest=hashlib.sha256(raw).hexdigest()
                if db.execute('SELECT 1 FROM jobs WHERE sha256=?',(digest,)).fetchone():report['duplicates']+=1;continue
                data=preview(raw);target=folder/(digest+'.jpg')
                temp=target.with_suffix('.tmp');temp.write_bytes(data);temp.replace(target)
                db.execute('INSERT INTO jobs VALUES (?,?,?,?,?)',(digest,str(path),str(target),int(time.time()),'ready'));db.commit()
                report['imported']+=1
            except (ValueError,OSError) as exc:report['rejected'].append({'file':path.name,'reason':str(exc)})
        (output/'import-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
        return report
    finally:db.close()

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--input',required=True);p.add_argument('--output',default='output/retrofit');a=p.parse_args()
    print(json.dumps(ingest(a.input,a.output),ensure_ascii=False,indent=2))
