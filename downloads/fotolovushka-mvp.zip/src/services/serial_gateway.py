"""USB newline frames. Radio packets as D:hex, durable ACK as A:hex."""
class SerialGateway:
    def __init__(self,port):
        try:
            import serial
        except ImportError as exc:
            raise RuntimeError('Install pyserial: python -m pip install -r requirements.txt') from exc
        self.serial = serial.Serial(port,115200,timeout=0.25,write_timeout=2)
        self.buffer = bytearray()

    def poll(self):
        self.buffer.extend(self.serial.read(self.serial.in_waiting or 1))
        if len(self.buffer)>8192:
            self.buffer.clear()
            raise ValueError('USB frame too large')
        if b'\n' not in self.buffer:
            return None
        line,_,rest = self.buffer.partition(b'\n')
        self.buffer = bytearray(rest)
        if line.startswith(b'D:'):
            return bytes.fromhex(line[2:].decode('ascii'))
        return None

    def ack(self,raw):
        self.serial.write(b'A:'+raw.hex().encode('ascii')+b'\n')

    def close(self):
        self.serial.close()
