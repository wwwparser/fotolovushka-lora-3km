import json
import os
import smtplib
import ssl
from email.message import EmailMessage
from pathlib import Path

def load_env(path='.env'):
    if Path(path).exists():
        for line in Path(path).read_text(encoding='utf-8-sig').splitlines():
            if line.strip() and not line.lstrip().startswith('#') and '=' in line:
                k,v = line.split('=',1)
                os.environ.setdefault(k.strip(),v.strip())

def send_image(path):
    load_env()
    keys = ['SMTP_HOST','SMTP_USER','SMTP_PASSWORD','SMTP_FROM','SMTP_TO']
    missing = [k for k in keys if not os.environ.get(k)]
    if missing:
        raise ValueError('Fill .env: ' + ', '.join(missing))
    path = Path(path)
    meta = json.loads(path.with_suffix('.json').read_text(encoding='utf-8'))
    msg = EmailMessage()
    msg['From'],msg['To'] = os.environ['SMTP_FROM'],os.environ['SMTP_TO']
    msg['Subject'] = f"Пост {meta['node']}, {meta['captured_utc']}"
    msg['Message-ID'] = f"<trail-{meta['node']}-{meta['image']}@local.invalid>"
    msg.set_content(f"Время UTC: {meta['captured_utc']}\nИсточник времени: {meta['time_source']}\n")
    msg.add_attachment(path.read_bytes(),maintype='image',subtype='jpeg',filename=path.name)
    port = int(os.environ.get('SMTP_PORT','465'))
    with smtplib.SMTP_SSL(os.environ['SMTP_HOST'],port,timeout=30,context=ssl.create_default_context()) as smtp:
        smtp.login(os.environ['SMTP_USER'],os.environ['SMTP_PASSWORD'])
        smtp.send_message(msg)
