import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch,MagicMock
from src.protocol import fragment
from src.receiver import Receiver
from src.services.mailer import send_image

class MailerTests(unittest.TestCase):
    def test_tls_message_attachment_and_queue(self):
        jpeg=b'\xff\xd8sample\xff\xd9'
        with tempfile.TemporaryDirectory() as directory:
            r=Receiver(directory)
            _,path=r.accept(next(fragment(jpeg,2,91,1700000000)).encode())
            env={'SMTP_HOST':'smtp.example.invalid','SMTP_PORT':'465','SMTP_USER':'test',
                 'SMTP_PASSWORD':'dummy','SMTP_FROM':'from@example.invalid','SMTP_TO':'to@example.invalid'}
            with patch.dict(os.environ,env,clear=True),patch('src.services.mailer.smtplib.SMTP_SSL') as smtp:
                send_image(path)
                smtp.assert_called_once()
                client=smtp.return_value.__enter__.return_value
                client.login.assert_called_once_with('test','dummy')
                msg=client.send_message.call_args.args[0]
                self.assertIn('Пост 2',msg['Subject'])
                self.assertEqual(list(msg.iter_attachments())[0].get_payload(decode=True),jpeg)
            self.assertEqual(len(r.pending()),1)
            r.mark_sent(2,91);self.assertEqual(r.pending(),[]);r.close()

    def test_missing_config_fails_clearly(self):
        with tempfile.TemporaryDirectory() as directory,patch.dict(os.environ,{},clear=True),patch('src.services.mailer.load_env'):
            with self.assertRaisesRegex(ValueError,'Fill .env: SMTP_HOST'):
                send_image(Path(directory)/'missing.jpg')

if __name__=='__main__':unittest.main()
