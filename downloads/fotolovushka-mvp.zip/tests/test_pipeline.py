import tempfile
import unittest
import zlib
from pathlib import Path
from dataclasses import replace
from src.protocol import Packet,fragment,HEADER
from src.receiver import Receiver

JPEG=b'\xff\xd8'+bytes(range(256))*24+b'\xff\xd9'

class PipelineTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.r=Receiver(self.temp.name)
    def tearDown(self):
        self.r.close();self.temp.cleanup()

    def test_wire_layout_and_ack(self):
        p=list(fragment(JPEG,1,42,1700000000))[0]
        self.assertEqual(HEADER.size,26)
        self.assertEqual(Packet.decode(p.encode()),p)
        self.assertEqual(Packet.decode(p.ack().encode()),p.ack())
        self.assertEqual(p.encode()[:10].hex(),'4654010101002a000000')

    def test_resume_out_of_order_four_nodes_duplicates(self):
        streams=[list(fragment(JPEG,n,n*100,1700000000)) for n in range(1,5)]
        for packets in streams:
            self.r.accept(packets[-1].encode())
            self.r.accept(packets[-1].encode())
        self.r.close();self.r=Receiver(self.temp.name)
        for packets in streams:
            for p in reversed(packets[:-1]):self.r.accept(p.encode())
            self.r.accept(packets[-1].encode()) # lost ACK retry after complete
        self.assertEqual(len(self.r.pending()),4)
        for n,img,path in self.r.pending():
            self.assertEqual(Path(path).read_bytes(),JPEG)
            self.r.mark_sent(n,img)
        self.assertEqual(self.r.pending(),[])

    def test_conflicting_duplicate_and_metadata_rejected(self):
        p=list(fragment(JPEG,1,44,0))[0];self.r.accept(p.encode())
        with self.assertRaises(ValueError):self.r.accept(replace(p,payload=b'x'+p.payload[1:]).encode())
        with self.assertRaises(ValueError):self.r.accept(replace(p,captured=3).encode())

    def test_bad_crc_final_not_acked_then_recovery(self):
        packets=list(fragment(JPEG,1,50,0))
        for p in packets[:-1]:self.r.accept(p.encode())
        p=packets[-1]
        with self.assertRaises(ValueError):self.r.accept(replace(p,payload=b'x'+p.payload[1:]).encode())
        self.assertEqual(self.r.pending(),[])
        _,out=self.r.accept(p.encode());self.assertEqual(out.read_bytes(),JPEG)

    def test_malformed_packets_rejected(self):
        p=list(fragment(JPEG,1,50,0))[0]
        for raw in (b'',b'x'*226,p.encode()[:-1],b'XX'+p.encode()[2:]):
            with self.assertRaises(ValueError):Packet.decode(raw)
        for p2 in (replace(p,node=5),replace(p,index=999),replace(p,total=999),replace(p,size=32769)):
            with self.assertRaises(ValueError):p2.encode()

    def test_non_jpeg_with_valid_crc_rejected(self):
        data=b'not a jpeg'
        p=list(fragment(data,1,99,0))[0]
        with self.assertRaises(ValueError):self.r.accept(p.encode())

if __name__=='__main__':unittest.main()
