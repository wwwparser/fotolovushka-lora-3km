import contextlib
import io
import tempfile
import unittest
from argparse import Namespace
from pathlib import Path
from src.cli import demo

class DemoTests(unittest.TestCase):
    def test_demo_can_run_twice_without_reusing_id(self):
        with tempfile.TemporaryDirectory() as directory:
            image=Path(directory)/'input.jpg';image.write_bytes(b'\xff\xd8'+b'\x01'*1100+b'\xff\xd9')
            out=Path(directory)/'out'
            args=Namespace(image=str(image),output=str(out),loss=.2,seed=7)
            with contextlib.redirect_stdout(io.StringIO()):
                demo(args);demo(args)
            files=list(out.glob('*.jpg'))
            self.assertEqual(len(files),2)
            self.assertTrue(all(p.read_bytes()==image.read_bytes() for p in files))

if __name__=='__main__':unittest.main()
