import io,tempfile,unittest,hashlib,sqlite3
from pathlib import Path
from PIL import Image
from src.retrofit import ingest
class RetrofitTest(unittest.TestCase):
    def test_original_preserved_preview_budget_and_resume(self):
        with tempfile.TemporaryDirectory() as root:
            root=Path(root);source=root/'input';source.mkdir();output=root/'out'
            buf=io.BytesIO();Image.effect_noise((1600,1200),90).convert('RGB').save(buf,format='JPEG',quality=95)
            raw=buf.getvalue();(source/'event.jpg').write_bytes(raw)
            (source/'partial.jpg').write_bytes(raw[:-2])
            result=ingest(source,output);self.assertEqual(result['imported'],1);self.assertEqual(len(result['rejected']),1)
            self.assertEqual((source/'event.jpg').read_bytes(),raw)
            dest=output/'previews'/(hashlib.sha256(raw).hexdigest()+'.jpg')
            self.assertLessEqual(dest.stat().st_size,5120)
            with Image.open(dest) as im:self.assertLessEqual(im.width,160);self.assertLessEqual(im.height,120)
            again=ingest(source,output);self.assertEqual(again['imported'],0);self.assertEqual(again['duplicates'],1)
    def test_output_cannot_be_in_camera_directory(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(ValueError):ingest(d,Path(d)/'output')
