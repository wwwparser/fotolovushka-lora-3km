#include "protocol.h"
#include <Wire.h>
#include <time.h>
#include "esp_sleep.h"
#include "driver/rtc_io.h"
constexpr int PIR=33, IR=25, CAM_POWER=32;
HardwareSerial Camera(2);
uint8_t photo[MAX_IMAGE];
void waitRadioBudget(){
  while(true){
    int32_t remaining=(int32_t)(radioReady-millis());
    if(remaining<=0)break;
    LoRa.sleep();
    esp_sleep_enable_timer_wakeup((uint64_t)remaining*1000);
    esp_light_sleep_start();
  }
}
int bcd(uint8_t b){return (b>>4)*10+(b&15);}
uint32_t rtcTime(){
  Wire.begin(21,22); Wire.beginTransmission(0x68);Wire.write(0x0f);
  if(Wire.endTransmission()!=0 || Wire.requestFrom(0x68,1)!=1)return 0;
  if(Wire.read()&0x80)return 0; // oscillator stop: clock must be set first
  Wire.beginTransmission(0x68);Wire.write(0);
  if(Wire.endTransmission()!=0 || Wire.requestFrom(0x68,7)!=7)return 0;
  uint8_t a[7];for(int i=0;i<7;i++)a[i]=Wire.read();
  if(a[2]&0x40)return 0; // require 24h mode
  struct tm t={}; t.tm_sec=bcd(a[0]&0x7f);t.tm_min=bcd(a[1]);t.tm_hour=bcd(a[2]&0x3f);
  t.tm_mday=bcd(a[4]);t.tm_mon=bcd(a[5]&0x1f)-1;t.tm_year=bcd(a[6])+100+((a[5]&0x80)?100:0);
  if(t.tm_mon<0||t.tm_mon>11||t.tm_mday<1||t.tm_mday>31||t.tm_hour>23||t.tm_min>59||t.tm_sec>59)return 0;
  return (uint32_t)mktime(&t); // default TZ UTC; DS3231 must store UTC
}
bool readBytes(uint8_t* dest,size_t n,uint32_t timeout){
  uint32_t until=millis()+timeout;size_t i=0;
  while(i<n && (int32_t)(until-millis())>0){if(Camera.available())dest[i++]=Camera.read();else delay(1);}
  return i==n;
}
uint32_t capture(){
  Camera.setRxBufferSize(4096);Camera.begin(115200,SERIAL_8N1,16,17);
  while(Camera.available())Camera.read();
  digitalWrite(IR,HIGH);digitalWrite(CAM_POWER,HIGH);
  uint32_t until=millis()+15000;int match=0;const char* marker="CAM1";
  while(match<4 && (int32_t)(until-millis())>0){
    if(Camera.available()){char c=Camera.read();match=c==marker[match]?match+1:(c=='C'?1:0);}else delay(1);
  }
  uint32_t size=0;
  bool ok=match==4 && readBytes((uint8_t*)&size,4,2000) && size<=MAX_IMAGE && size>0;
  if(ok)ok=readBytes(photo,size,7000);
  digitalWrite(IR,LOW);digitalWrite(CAM_POWER,LOW);Camera.end();
  return ok && size>=4 && photo[0]==255 && photo[1]==216 && photo[size-2]==255 && photo[size-1]==217?size:0;
}
bool transmit(uint32_t size,uint32_t captured){
  Header h={{'F','T'},1,1,NODE_ID,esp_random(),0,(uint16_t)((size+CHUNK-1)/CHUNK),captured,size,crc32(photo,size)};
  uint8_t packet[sizeof(Header)+CHUNK];
  for(h.index=0;h.index<h.total;h.index++){
    int len=min(CHUNK,(int)(size-h.index*CHUNK));
    memcpy(packet,&h,sizeof(h));memcpy(packet+sizeof(h),photo+h.index*CHUNK,len);
    bool acked=false;
    for(int attempt=0;attempt<5 && !acked;attempt++){
      waitRadioBudget();
      if(!sendRF(packet,sizeof(h)+len))return false;
      uint32_t until=millis()+15000;
      while((int32_t)(until-millis())>0){
        int n=LoRa.parsePacket();
        if(n==sizeof(Header)){
          Header a;LoRa.readBytes((uint8_t*)&a,sizeof(a));
          Header expected=h;expected.kind=2;
          if(memcmp(&a,&expected,sizeof(a))==0){acked=true;break;}
        }else if(n){while(LoRa.available())LoRa.read();}
        delay(1);
      }
      LoRa.sleep();
      if(!acked)delay(esp_random()%1000);
    }
    if(!acked)return false;
  }
  return true;
}
void setup(){
  rtc_gpio_hold_dis((gpio_num_t)IR);rtc_gpio_hold_dis((gpio_num_t)CAM_POWER);
  pinMode(PIR,INPUT_PULLDOWN);pinMode(IR,OUTPUT);pinMode(CAM_POWER,OUTPUT);
  digitalWrite(IR,LOW);digitalWrite(CAM_POWER,LOW);
  Serial.begin(115200);
  bool radio=initRadio();
  uint32_t captured=rtcTime(),size=capture();
  bool ok=radio && size && transmit(size,captured);
  Serial.printf("capture=%u transmit=%s\n",size,ok?"ACKED":"FAILED/DISABLED");
  if(radio)LoRa.sleep();
  // Honor remaining radio off-time BEFORE a reboot resets millis().
  if(radio)waitRadioBudget();
  // PIR stuck high must not create a permanent immediate-wake loop.
  uint32_t until=millis()+30000;
  while(digitalRead(PIR) && (int32_t)(until-millis())>0)delay(100);
  rtc_gpio_hold_en((gpio_num_t)IR);rtc_gpio_hold_en((gpio_num_t)CAM_POWER);
  if(!digitalRead(PIR))esp_sleep_enable_ext0_wakeup((gpio_num_t)PIR,1);
  else esp_sleep_enable_timer_wakeup(60ULL*1000000);
  esp_deep_sleep_start();
}
void loop(){}
