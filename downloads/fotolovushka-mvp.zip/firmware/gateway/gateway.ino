#include "protocol.h"
String input;
void setup(){Serial.begin(115200);if(!initRadio())Serial.println("ERROR: radio init");}
int unhex(char c){if(c>='0'&&c<='9')return c-'0';if(c>='a'&&c<='f')return c-'a'+10;if(c>='A'&&c<='F')return c-'A'+10;return -1;}
void processLine(){
  input.trim();
  if(input.startsWith("A:") && input.length()==2+2*sizeof(Header)){
    uint8_t raw[sizeof(Header)];bool valid=true;
    for(int i=0;i<sizeof(Header);i++){int a=unhex(input[2+2*i]),b=unhex(input[3+2*i]);if(a<0||b<0){valid=false;break;}raw[i]=(a<<4)|b;}
    Header h;memcpy(&h,raw,sizeof(h));
    if(valid && validHeader(h) && h.kind==2)sendRF(raw,sizeof(raw));
  }
  input="";
}
void loop(){
  while(Serial.available()){char c=Serial.read();if(c=='\n')processLine();else if(input.length()<520)input+=c;else input="";}
  int n=LoRa.parsePacket();
  if(n>0 && n<=sizeof(Header)+CHUNK){
    uint8_t raw[sizeof(Header)+CHUNK];int len=LoRa.readBytes(raw,n);
    if(len>=sizeof(Header)){
      Header h;memcpy(&h,raw,sizeof(h));
      int expected=sizeof(Header)+min(CHUNK,(int)(h.size-h.index*CHUNK));
      if(validHeader(h) && h.kind==1 && len==expected){
        Serial.print("D:");for(int i=0;i<len;i++)Serial.printf("%02x",raw[i]);Serial.println();
      }
    }
  }
}
