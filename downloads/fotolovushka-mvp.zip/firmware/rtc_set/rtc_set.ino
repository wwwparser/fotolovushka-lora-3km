#include <Arduino.h>
#include <Wire.h>
#include <time.h>
uint8_t bcd(int x){return (x/10)*16+x%10;}
void setup(){Wire.begin(21,22);Serial.begin(115200);Serial.println("Send UNIX UTC seconds, newline. Then flash node.");}
void loop(){
  if(!Serial.available())return;
  String s=Serial.readStringUntil('\n');time_t ts=(time_t)strtoul(s.c_str(),nullptr,10);
  if(ts<1700000000){Serial.println("Invalid UTC");return;}
  struct tm t;gmtime_r(&ts,&t);
  Wire.beginTransmission(0x68);Wire.write(0);
  uint8_t a[]={bcd(t.tm_sec),bcd(t.tm_min),bcd(t.tm_hour),bcd(t.tm_wday+1),bcd(t.tm_mday),bcd(t.tm_mon+1),bcd((t.tm_year+1900)%100)};
  Wire.write(a,7);if(Wire.endTransmission()){Serial.println("RTC missing");return;}
  Wire.beginTransmission(0x68);Wire.write(0x0f);Wire.write(0);Wire.endTransmission();
  Serial.println("RTC set UTC");
}
