#pragma once
#include <Arduino.h>
#include <SPI.h>
#include <LoRa.h>
#include <math.h>

// Prototype: choose legal frequency/power/duty for actual location before enabling.
#define ENABLE_RF_TX 0
constexpr long RF_HZ = 868950000;
constexpr uint8_t RF_SF = 7;
constexpr uint8_t NODE_ID = 1;
constexpr float DUTY = 0.01f; // conservative engineering scenario, not legal opinion
constexpr int CHUNK = 200, MAX_IMAGE = 32768;
constexpr int RF_CS=5, RF_RST=14, RF_DIO=26;
struct __attribute__((packed)) Header {
  char magic[2]; uint8_t version,kind; uint16_t node;
  uint32_t image; uint16_t index,total; uint32_t captured,size,crc;
};
static_assert(sizeof(Header)==26,"Python wire layout must match");
uint32_t crc32(const uint8_t* p,size_t n) {
  uint32_t c=0xffffffff;
  for(size_t i=0;i<n;i++){c^=p[i];for(int k=0;k<8;k++)c=(c>>1)^((c&1)?0xedb88320:0);}
  return ~c;
}
bool validHeader(const Header& h) {
  return h.magic[0]=='F' && h.magic[1]=='T' && h.version==1 &&
    (h.kind==1||h.kind==2) && h.node>=1 && h.node<=4 && h.size>0 &&
    h.size<=MAX_IMAGE && h.total==(h.size+CHUNK-1)/CHUNK && h.index<h.total;
}
float airtimeMs(int bytes) {
  int de=RF_SF>=11?1:0;
  float sy=powf(2,RF_SF)/125000.0f;
  float ps=8+max(0,(int)ceilf((8*bytes-4*RF_SF+28+16.0f)/(4*(RF_SF-2*de))))*5;
  return (12.25f+ps)*sy*1000;
}
uint32_t radioReady=0;
bool initRadio() {
  SPI.begin(18,19,23,RF_CS);
  LoRa.setPins(RF_CS,RF_RST,RF_DIO);
  if(!LoRa.begin(RF_HZ))return false;
  LoRa.setSpreadingFactor(RF_SF); LoRa.setSignalBandwidth(125000);
  LoRa.setCodingRate4(5); LoRa.setSyncWord(0x12); LoRa.enableCrc();
  LoRa.setTxPower(10); // dBm conducted; account for antenna gain/EIRP separately
  radioReady=millis()+(uint32_t)ceilf(airtimeMs(sizeof(Header)+CHUNK)*(1/DUTY-1));
  return true;
}
bool sendRF(const uint8_t* data,int n) {
  if(!ENABLE_RF_TX)return false;
  while((int32_t)(radioReady-millis())>0) delay(10);
  LoRa.beginPacket(); LoRa.write(data,n); LoRa.endPacket();
  radioReady=millis()+(uint32_t)ceilf(airtimeMs(n)*(1/DUTY-1));
  return true;
}
