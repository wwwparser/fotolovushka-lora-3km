// AI Thinker ESP32-CAM, PSRAM enabled. Power-cycled by radio controller.
#include <Arduino.h>
#include "esp_camera.h"
#include "esp_sleep.h"
void setup() {
  Serial.begin(115200); Serial.setDebugOutput(false);
  camera_config_t c={};
  c.ledc_channel=LEDC_CHANNEL_0; c.ledc_timer=LEDC_TIMER_0;
  c.pin_d0=5;c.pin_d1=18;c.pin_d2=19;c.pin_d3=21;c.pin_d4=36;c.pin_d5=39;c.pin_d6=34;c.pin_d7=35;
  c.pin_xclk=0;c.pin_pclk=22;c.pin_vsync=25;c.pin_href=23;
  c.pin_sccb_sda=26;c.pin_sccb_scl=27;c.pin_pwdn=32;c.pin_reset=-1;
  c.xclk_freq_hz=20000000;c.pixel_format=PIXFORMAT_JPEG;c.frame_size=FRAMESIZE_QQVGA;
  c.jpeg_quality=35;c.fb_count=1;c.fb_location=CAMERA_FB_IN_PSRAM;c.grab_mode=CAMERA_GRAB_WHEN_EMPTY;
  if(esp_camera_init(&c)!=ESP_OK){esp_deep_sleep_start();return;}
  // Allow AEC settling with IR already on. Discard early exposures.
  delay(800);
  for(int i=0;i<3;i++){camera_fb_t* f=esp_camera_fb_get();if(f)esp_camera_fb_return(f);delay(100);}
  camera_fb_t* f=esp_camera_fb_get();
  if(f && f->len>0 && f->len<=32768){
    Serial.write((const uint8_t*)"CAM1",4);
    uint32_t size=f->len;
    Serial.write((uint8_t*)&size,4);Serial.write(f->buf,f->len);Serial.flush();
  }
  if(f)esp_camera_fb_return(f);
  esp_camera_deinit();esp_deep_sleep_start();
}
void loop() {}
