Prototype v0.2. Units mm. Print fit_coupon first. See https://wwwparser.github.io/fotolovushka-lora-3km/case.html
Not physically printed or waterproof tested.
